--
-- PostgreSQL database dump
--

\restrict RVy8xCtXC7NOovN3fYaJ3ya2cyNboWLgy0q8KhV4S0uZE3w3bJyVfnPhTTIHQVd

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

-- Started on 2026-03-26 07:55:31

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 238 (class 1259 OID 41755)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    audit_id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer,
    old_values jsonb,
    new_values jsonb,
    ip_address character varying(45),
    user_agent text,
    status character varying(20) DEFAULT 'success'::character varying,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT audit_logs_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failure'::character varying])::text[])))
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 41754)
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_audit_id_seq OWNER TO postgres;

--
-- TOC entry 5116 (class 0 OID 0)
-- Dependencies: 237
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_audit_id_seq OWNED BY public.audit_logs.audit_id;


--
-- TOC entry 224 (class 1259 OID 33772)
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    customer_name character varying(100) NOT NULL,
    phone character varying(20),
    email character varying(100),
    loyalty_points integer DEFAULT 0,
    total_purchases numeric(12,2) DEFAULT 0,
    is_registered boolean DEFAULT true,
    registered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT customers_loyalty_points_check CHECK ((loyalty_points >= 0)),
    CONSTRAINT customers_total_purchases_check CHECK ((total_purchases >= (0)::numeric))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 33771)
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_customer_id_seq OWNER TO postgres;

--
-- TOC entry 5117 (class 0 OID 0)
-- Dependencies: 223
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- TOC entry 222 (class 1259 OID 33751)
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity_on_hand integer DEFAULT 0,
    reorder_level integer DEFAULT 10,
    reorder_quantity integer DEFAULT 50,
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT inventory_quantity_on_hand_check CHECK ((quantity_on_hand >= 0)),
    CONSTRAINT inventory_reorder_level_check CHECK ((reorder_level >= 0)),
    CONSTRAINT inventory_reorder_quantity_check CHECK ((reorder_quantity > 0))
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 33857)
-- Name: inventory_adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_adjustments (
    adjustment_id integer NOT NULL,
    product_id integer NOT NULL,
    adjustment_quantity integer NOT NULL,
    adjustment_type character varying(20) NOT NULL,
    reason text,
    adjusted_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT inventory_adjustments_adjustment_type_check CHECK (((adjustment_type)::text = ANY ((ARRAY['add'::character varying, 'reduce'::character varying, 'correction'::character varying])::text[])))
);


ALTER TABLE public.inventory_adjustments OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 33856)
-- Name: inventory_adjustments_adjustment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_adjustments_adjustment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_adjustments_adjustment_id_seq OWNER TO postgres;

--
-- TOC entry 5118 (class 0 OID 0)
-- Dependencies: 231
-- Name: inventory_adjustments_adjustment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_adjustments_adjustment_id_seq OWNED BY public.inventory_adjustments.adjustment_id;


--
-- TOC entry 221 (class 1259 OID 33750)
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_inventory_id_seq OWNER TO postgres;

--
-- TOC entry 5119 (class 0 OID 0)
-- Dependencies: 221
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- TOC entry 230 (class 1259 OID 33834)
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id integer NOT NULL,
    sale_id integer NOT NULL,
    payment_method character varying(20) NOT NULL,
    amount_paid numeric(12,2) NOT NULL,
    change_amount numeric(10,2) DEFAULT 0,
    payment_status character varying(20) DEFAULT 'completed'::character varying,
    payment_details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT payments_amount_paid_check CHECK ((amount_paid > (0)::numeric)),
    CONSTRAINT payments_change_amount_check CHECK ((change_amount >= (0)::numeric)),
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'mobile_money'::character varying, 'card'::character varying, 'split'::character varying])::text[]))),
    CONSTRAINT payments_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['completed'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 33833)
-- Name: payments_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_payment_id_seq OWNER TO postgres;

--
-- TOC entry 5120 (class 0 OID 0)
-- Dependencies: 229
-- Name: payments_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_payment_id_seq OWNED BY public.payments.payment_id;


--
-- TOC entry 236 (class 1259 OID 41734)
-- Name: product_suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_suppliers (
    product_supplier_id integer NOT NULL,
    product_id integer NOT NULL,
    supplier_id integer NOT NULL,
    supplier_sku character varying(50),
    supplier_unit_price numeric(10,2),
    lead_time_days integer,
    minimum_order_qty integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.product_suppliers OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 41733)
-- Name: product_suppliers_product_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_suppliers_product_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_suppliers_product_supplier_id_seq OWNER TO postgres;

--
-- TOC entry 5121 (class 0 OID 0)
-- Dependencies: 235
-- Name: product_suppliers_product_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_suppliers_product_supplier_id_seq OWNED BY public.product_suppliers.product_supplier_id;


--
-- TOC entry 220 (class 1259 OID 33731)
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    product_name character varying(100) NOT NULL,
    barcode character varying(50),
    category character varying(50) NOT NULL,
    description text,
    unit_price numeric(10,2) NOT NULL,
    cost_price numeric(10,2),
    is_active boolean DEFAULT true,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT products_unit_price_check CHECK ((unit_price > (0)::numeric))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 33730)
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_product_id_seq OWNER TO postgres;

--
-- TOC entry 5122 (class 0 OID 0)
-- Dependencies: 219
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- TOC entry 240 (class 1259 OID 41772)
-- Name: rate_limit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_limit_logs (
    limit_id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    endpoint character varying(255) NOT NULL,
    request_count integer DEFAULT 1,
    window_start timestamp without time zone,
    window_end timestamp without time zone,
    is_blocked boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rate_limit_logs OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 41771)
-- Name: rate_limit_logs_limit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rate_limit_logs_limit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limit_logs_limit_id_seq OWNER TO postgres;

--
-- TOC entry 5123 (class 0 OID 0)
-- Dependencies: 239
-- Name: rate_limit_logs_limit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rate_limit_logs_limit_id_seq OWNED BY public.rate_limit_logs.limit_id;


--
-- TOC entry 226 (class 1259 OID 33786)
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    sale_id integer NOT NULL,
    transaction_id character varying(50) NOT NULL,
    cashier_id integer NOT NULL,
    customer_id integer,
    subtotal numeric(12,2) NOT NULL,
    discount_amount numeric(10,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    total_amount numeric(12,2) NOT NULL,
    sale_status character varying(20) DEFAULT 'completed'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sales_discount_amount_check CHECK ((discount_amount >= (0)::numeric)),
    CONSTRAINT sales_sale_status_check CHECK (((sale_status)::text = ANY ((ARRAY['completed'::character varying, 'pending'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT sales_subtotal_check CHECK ((subtotal >= (0)::numeric)),
    CONSTRAINT sales_tax_amount_check CHECK ((tax_amount >= (0)::numeric)),
    CONSTRAINT sales_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 33814)
-- Name: sales_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_items (
    sale_item_id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    item_total numeric(12,2) NOT NULL,
    CONSTRAINT sales_items_item_total_check CHECK ((item_total > (0)::numeric)),
    CONSTRAINT sales_items_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT sales_items_unit_price_check CHECK ((unit_price > (0)::numeric))
);


ALTER TABLE public.sales_items OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 33813)
-- Name: sales_items_sale_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_items_sale_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_items_sale_item_id_seq OWNER TO postgres;

--
-- TOC entry 5124 (class 0 OID 0)
-- Dependencies: 227
-- Name: sales_items_sale_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_items_sale_item_id_seq OWNED BY public.sales_items.sale_item_id;


--
-- TOC entry 225 (class 1259 OID 33785)
-- Name: sales_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_sale_id_seq OWNER TO postgres;

--
-- TOC entry 5125 (class 0 OID 0)
-- Dependencies: 225
-- Name: sales_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_sale_id_seq OWNED BY public.sales.sale_id;


--
-- TOC entry 234 (class 1259 OID 41722)
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    supplier_id integer NOT NULL,
    supplier_name character varying(100) NOT NULL,
    contact_person character varying(100),
    phone character varying(20),
    email character varying(100),
    address text,
    city character varying(50),
    country character varying(50),
    payment_terms character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 41721)
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_supplier_id_seq OWNER TO postgres;

--
-- TOC entry 5126 (class 0 OID 0)
-- Dependencies: 233
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_supplier_id_seq OWNED BY public.suppliers.supplier_id;


--
-- TOC entry 218 (class 1259 OID 33714)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['administrator'::character varying, 'manager'::character varying, 'cashier'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 33713)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- TOC entry 5127 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 4835 (class 2604 OID 41758)
-- Name: audit_logs audit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN audit_id SET DEFAULT nextval('public.audit_logs_audit_id_seq'::regclass);


--
-- TOC entry 4810 (class 2604 OID 33775)
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- TOC entry 4805 (class 2604 OID 33754)
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- TOC entry 4826 (class 2604 OID 33860)
-- Name: inventory_adjustments adjustment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_adjustments ALTER COLUMN adjustment_id SET DEFAULT nextval('public.inventory_adjustments_adjustment_id_seq'::regclass);


--
-- TOC entry 4822 (class 2604 OID 33837)
-- Name: payments payment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN payment_id SET DEFAULT nextval('public.payments_payment_id_seq'::regclass);


--
-- TOC entry 4832 (class 2604 OID 41737)
-- Name: product_suppliers product_supplier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers ALTER COLUMN product_supplier_id SET DEFAULT nextval('public.product_suppliers_product_supplier_id_seq'::regclass);


--
-- TOC entry 4801 (class 2604 OID 33734)
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- TOC entry 4838 (class 2604 OID 41775)
-- Name: rate_limit_logs limit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_limit_logs ALTER COLUMN limit_id SET DEFAULT nextval('public.rate_limit_logs_limit_id_seq'::regclass);


--
-- TOC entry 4816 (class 2604 OID 33789)
-- Name: sales sale_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN sale_id SET DEFAULT nextval('public.sales_sale_id_seq'::regclass);


--
-- TOC entry 4821 (class 2604 OID 33817)
-- Name: sales_items sale_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items ALTER COLUMN sale_item_id SET DEFAULT nextval('public.sales_items_sale_item_id_seq'::regclass);


--
-- TOC entry 4828 (class 2604 OID 41725)
-- Name: suppliers supplier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplier_id SET DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass);


--
-- TOC entry 4797 (class 2604 OID 33717)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 5108 (class 0 OID 41755)
-- Dependencies: 238
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (audit_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, status, error_message, created_at) FROM stdin;
\.


--
-- TOC entry 5094 (class 0 OID 33772)
-- Dependencies: 224
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, customer_name, phone, email, loyalty_points, total_purchases, is_registered, registered_at, updated_at) FROM stdin;
5	Joseph Mawuli	+233534710207	kpetigojoseph4@gmail.com	100	5500.00	t	2026-03-26 00:48:04.826493	2026-03-26 00:48:49.998362
\.


--
-- TOC entry 5092 (class 0 OID 33751)
-- Dependencies: 222
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventory_id, product_id, quantity_on_hand, reorder_level, reorder_quantity, last_updated) FROM stdin;
1	1	0	10	50	2026-03-21 08:34:13.093061
2	3	0	10	50	2026-03-21 09:19:19.551811
3	2	56	10	50	2026-03-26 00:48:49.998362
\.


--
-- TOC entry 5102 (class 0 OID 33857)
-- Dependencies: 232
-- Data for Name: inventory_adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_adjustments (adjustment_id, product_id, adjustment_quantity, adjustment_type, reason, adjusted_by, created_at) FROM stdin;
1	2	10	add	\N	4	2026-03-21 09:38:32.41629
2	2	50	add	\N	4	2026-03-21 09:38:50.997968
\.


--
-- TOC entry 5100 (class 0 OID 33834)
-- Dependencies: 230
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, sale_id, payment_method, amount_paid, change_amount, payment_status, payment_details, created_at) FROM stdin;
1	1	cash	6000.00	500.00	completed	{}	2026-03-21 13:45:07.285333
2	2	cash	6000.00	500.00	completed	{}	2026-03-25 22:00:48.92368
3	3	cash	8000.00	2500.00	completed	{}	2026-03-25 22:50:08.381242
4	4	cash	110000.00	104500.00	completed	{}	2026-03-26 00:48:50.233926
\.


--
-- TOC entry 5106 (class 0 OID 41734)
-- Dependencies: 236
-- Data for Name: product_suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_suppliers (product_supplier_id, product_id, supplier_id, supplier_sku, supplier_unit_price, lead_time_days, minimum_order_qty, created_at) FROM stdin;
\.


--
-- TOC entry 5090 (class 0 OID 33731)
-- Dependencies: 220
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, product_name, barcode, category, description, unit_price, cost_price, is_active, created_by, created_at, updated_at) FROM stdin;
1	Iphone 13	\N	Electronics	\N	3500.00	3000.00	f	\N	2026-03-21 08:34:13.060015	2026-03-21 09:18:47.330606
2	JBL Headset	\N	Electronics	\N	5000.00	4000.00	t	1	2026-03-21 09:19:19.527594	2026-03-21 09:19:19.527594
3	JBL Headset	\N	Electronics	\N	5000.00	4000.00	f	1	2026-03-21 09:19:19.524184	2026-03-21 09:19:28.739008
\.


--
-- TOC entry 5110 (class 0 OID 41772)
-- Dependencies: 240
-- Data for Name: rate_limit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_limit_logs (limit_id, ip_address, endpoint, request_count, window_start, window_end, is_blocked, created_at) FROM stdin;
\.


--
-- TOC entry 5096 (class 0 OID 33786)
-- Dependencies: 226
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (sale_id, transaction_id, cashier_id, customer_id, subtotal, discount_amount, tax_amount, total_amount, sale_status, created_at) FROM stdin;
1	TXN20260321007071009603	1	\N	5000.00	0.00	500.00	5500.00	completed	2026-03-21 13:45:06.904272
2	TXN20260325760488067836	1	\N	5000.00	0.00	500.00	5500.00	completed	2026-03-25 22:00:48.668105
3	TXN20260325790083016512	4	\N	5000.00	0.00	500.00	5500.00	completed	2026-03-25 22:50:08.236612
4	TXN20260326861301542194	1	5	5000.00	0.00	500.00	5500.00	completed	2026-03-26 00:48:49.998362
\.


--
-- TOC entry 5098 (class 0 OID 33814)
-- Dependencies: 228
-- Data for Name: sales_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_items (sale_item_id, sale_id, product_id, quantity, unit_price, item_total) FROM stdin;
1	1	2	1	5000.00	5000.00
2	2	2	1	5000.00	5000.00
3	3	2	1	5000.00	5000.00
4	4	2	1	5000.00	5000.00
\.


--
-- TOC entry 5104 (class 0 OID 41722)
-- Dependencies: 234
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (supplier_id, supplier_name, contact_person, phone, email, address, city, country, payment_terms, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5088 (class 0 OID 33714)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, email, password_hash, role, first_name, last_name, is_active, created_at, updated_at) FROM stdin;
1	Joe	kpetigojoseph80@gmail.com	$2a$10$Vr8exzyzS1FkQqo33pf4ze0J4d8LpIsQS3299YLYKe/EsWx8tfAbG	administrator	Joe	\N	t	2026-03-21 07:38:16.17187	2026-03-21 07:38:16.17187
2	Kojo	kpetigojoseph4@gmail.com	$2a$10$ibV8wQOqXOUVlFG.6P1freTo6m/ktTTz1NTKILZEVZRy3NCwvIlM2	cashier	Kojo	\N	t	2026-03-21 08:30:07.300672	2026-03-21 08:30:07.300672
4	Mawuli	josephmawulikpetigo@gmail.com	$2a$10$5a0S21oLtna9eoY196wwB.iLsRO2w.Hj/jyIBSoJNo9MXy.atUlAy	manager	Mawuli	\N	f	2026-03-21 09:00:18.30349	2026-03-26 01:24:30.270647
\.


--
-- TOC entry 5128 (class 0 OID 0)
-- Dependencies: 237
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_audit_id_seq', 1, false);


--
-- TOC entry 5129 (class 0 OID 0)
-- Dependencies: 223
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 5, true);


--
-- TOC entry 5130 (class 0 OID 0)
-- Dependencies: 231
-- Name: inventory_adjustments_adjustment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_adjustments_adjustment_id_seq', 2, true);


--
-- TOC entry 5131 (class 0 OID 0)
-- Dependencies: 221
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 3, true);


--
-- TOC entry 5132 (class 0 OID 0)
-- Dependencies: 229
-- Name: payments_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_payment_id_seq', 4, true);


--
-- TOC entry 5133 (class 0 OID 0)
-- Dependencies: 235
-- Name: product_suppliers_product_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_suppliers_product_supplier_id_seq', 1, false);


--
-- TOC entry 5134 (class 0 OID 0)
-- Dependencies: 219
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_product_id_seq', 3, true);


--
-- TOC entry 5135 (class 0 OID 0)
-- Dependencies: 239
-- Name: rate_limit_logs_limit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rate_limit_logs_limit_id_seq', 1, false);


--
-- TOC entry 5136 (class 0 OID 0)
-- Dependencies: 227
-- Name: sales_items_sale_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_items_sale_item_id_seq', 4, true);


--
-- TOC entry 5137 (class 0 OID 0)
-- Dependencies: 225
-- Name: sales_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_sale_id_seq', 4, true);


--
-- TOC entry 5138 (class 0 OID 0)
-- Dependencies: 233
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 1, false);


--
-- TOC entry 5139 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 4, true);


--
-- TOC entry 4920 (class 2606 OID 41765)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (audit_id);


--
-- TOC entry 4884 (class 2606 OID 33784)
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4908 (class 2606 OID 33866)
-- Name: inventory_adjustments inventory_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_pkey PRIMARY KEY (adjustment_id);


--
-- TOC entry 4880 (class 2606 OID 33763)
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- TOC entry 4882 (class 2606 OID 33765)
-- Name: inventory inventory_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_key UNIQUE (product_id);


--
-- TOC entry 4902 (class 2606 OID 33848)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- TOC entry 4904 (class 2606 OID 33850)
-- Name: payments payments_sale_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_key UNIQUE (sale_id);


--
-- TOC entry 4916 (class 2606 OID 41741)
-- Name: product_suppliers product_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_pkey PRIMARY KEY (product_supplier_id);


--
-- TOC entry 4918 (class 2606 OID 41743)
-- Name: product_suppliers product_suppliers_product_id_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_product_id_supplier_id_key UNIQUE (product_id, supplier_id);


--
-- TOC entry 4875 (class 2606 OID 33744)
-- Name: products products_barcode_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_barcode_key UNIQUE (barcode);


--
-- TOC entry 4877 (class 2606 OID 33742)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- TOC entry 4929 (class 2606 OID 41780)
-- Name: rate_limit_logs rate_limit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_limit_logs
    ADD CONSTRAINT rate_limit_logs_pkey PRIMARY KEY (limit_id);


--
-- TOC entry 4898 (class 2606 OID 33822)
-- Name: sales_items sales_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_pkey PRIMARY KEY (sale_item_id);


--
-- TOC entry 4892 (class 2606 OID 33800)
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (sale_id);


--
-- TOC entry 4894 (class 2606 OID 33802)
-- Name: sales sales_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_transaction_id_key UNIQUE (transaction_id);


--
-- TOC entry 4912 (class 2606 OID 41732)
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- TOC entry 4866 (class 2606 OID 33729)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4868 (class 2606 OID 33725)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4870 (class 2606 OID 33727)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4921 (class 1259 OID 41788)
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- TOC entry 4922 (class 1259 OID 41787)
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- TOC entry 4923 (class 1259 OID 41786)
-- Name: idx_audit_logs_entity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_entity_type ON public.audit_logs USING btree (entity_type);


--
-- TOC entry 4924 (class 1259 OID 41785)
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- TOC entry 4885 (class 1259 OID 33883)
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- TOC entry 4886 (class 1259 OID 33884)
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- TOC entry 4905 (class 1259 OID 33894)
-- Name: idx_inventory_adjustments_adjusted_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_adjustments_adjusted_by ON public.inventory_adjustments USING btree (adjusted_by);


--
-- TOC entry 4906 (class 1259 OID 33893)
-- Name: idx_inventory_adjustments_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_adjustments_product_id ON public.inventory_adjustments USING btree (product_id);


--
-- TOC entry 4878 (class 1259 OID 33882)
-- Name: idx_inventory_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_product_id ON public.inventory USING btree (product_id);


--
-- TOC entry 4899 (class 1259 OID 33892)
-- Name: idx_payments_payment_method; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_payment_method ON public.payments USING btree (payment_method);


--
-- TOC entry 4900 (class 1259 OID 33891)
-- Name: idx_payments_sale_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_sale_id ON public.payments USING btree (sale_id);


--
-- TOC entry 4913 (class 1259 OID 41783)
-- Name: idx_product_suppliers_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_suppliers_product_id ON public.product_suppliers USING btree (product_id);


--
-- TOC entry 4914 (class 1259 OID 41784)
-- Name: idx_product_suppliers_supplier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_suppliers_supplier_id ON public.product_suppliers USING btree (supplier_id);


--
-- TOC entry 4871 (class 1259 OID 33880)
-- Name: idx_products_barcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_barcode ON public.products USING btree (barcode);


--
-- TOC entry 4872 (class 1259 OID 33879)
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_category ON public.products USING btree (category);


--
-- TOC entry 4873 (class 1259 OID 33881)
-- Name: idx_products_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_is_active ON public.products USING btree (is_active);


--
-- TOC entry 4925 (class 1259 OID 41790)
-- Name: idx_rate_limit_logs_endpoint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_limit_logs_endpoint ON public.rate_limit_logs USING btree (endpoint);


--
-- TOC entry 4926 (class 1259 OID 41789)
-- Name: idx_rate_limit_logs_ip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_limit_logs_ip ON public.rate_limit_logs USING btree (ip_address);


--
-- TOC entry 4927 (class 1259 OID 41791)
-- Name: idx_rate_limit_logs_window; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_limit_logs_window ON public.rate_limit_logs USING btree (window_start, window_end);


--
-- TOC entry 4887 (class 1259 OID 33885)
-- Name: idx_sales_cashier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_cashier_id ON public.sales USING btree (cashier_id);


--
-- TOC entry 4888 (class 1259 OID 33888)
-- Name: idx_sales_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_created_at ON public.sales USING btree (created_at);


--
-- TOC entry 4889 (class 1259 OID 33886)
-- Name: idx_sales_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_customer_id ON public.sales USING btree (customer_id);


--
-- TOC entry 4895 (class 1259 OID 33890)
-- Name: idx_sales_items_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_items_product_id ON public.sales_items USING btree (product_id);


--
-- TOC entry 4896 (class 1259 OID 33889)
-- Name: idx_sales_items_sale_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_items_sale_id ON public.sales_items USING btree (sale_id);


--
-- TOC entry 4890 (class 1259 OID 33887)
-- Name: idx_sales_transaction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_transaction_id ON public.sales USING btree (transaction_id);


--
-- TOC entry 4909 (class 1259 OID 41782)
-- Name: idx_suppliers_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_email ON public.suppliers USING btree (email);


--
-- TOC entry 4910 (class 1259 OID 41781)
-- Name: idx_suppliers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_name ON public.suppliers USING btree (supplier_name);


--
-- TOC entry 4863 (class 1259 OID 33878)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 4864 (class 1259 OID 33877)
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- TOC entry 4941 (class 2606 OID 41766)
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- TOC entry 4937 (class 2606 OID 33872)
-- Name: inventory_adjustments inventory_adjustments_adjusted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_adjusted_by_fkey FOREIGN KEY (adjusted_by) REFERENCES public.users(user_id) ON DELETE RESTRICT;


--
-- TOC entry 4938 (class 2606 OID 33867)
-- Name: inventory_adjustments inventory_adjustments_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 4931 (class 2606 OID 33766)
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 4936 (class 2606 OID 33851)
-- Name: payments payments_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(sale_id) ON DELETE CASCADE;


--
-- TOC entry 4939 (class 2606 OID 41744)
-- Name: product_suppliers product_suppliers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 4940 (class 2606 OID 41749)
-- Name: product_suppliers product_suppliers_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id) ON DELETE CASCADE;


--
-- TOC entry 4930 (class 2606 OID 33745)
-- Name: products products_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- TOC entry 4932 (class 2606 OID 33803)
-- Name: sales sales_cashier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_cashier_id_fkey FOREIGN KEY (cashier_id) REFERENCES public.users(user_id) ON DELETE RESTRICT;


--
-- TOC entry 4933 (class 2606 OID 33808)
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id) ON DELETE SET NULL;


--
-- TOC entry 4934 (class 2606 OID 33828)
-- Name: sales_items sales_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE RESTRICT;


--
-- TOC entry 4935 (class 2606 OID 33823)
-- Name: sales_items sales_items_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(sale_id) ON DELETE CASCADE;


-- Completed on 2026-03-26 07:55:33

--
-- PostgreSQL database dump complete
--

\unrestrict RVy8xCtXC7NOovN3fYaJ3ya2cyNboWLgy0q8KhV4S0uZE3w3bJyVfnPhTTIHQVd

